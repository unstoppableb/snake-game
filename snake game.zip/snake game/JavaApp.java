public class JavaApp {
	public static void main (String args[]){
		new Snakegames().setVisible(true);
	}
    
}