import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/*
 * Created by JFormDesigner on Fri Dec 15 22:10:28 PST 2023
 */
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;



/**
 * @author lachi
 */
public class Snakegames extends JFrame {
	public Snakegames() {
		initComponents();
	}

	private void btnSKeyPressed(KeyEvent e) {
		// TODO add your code here
	}

	private void btnSKeyReleased(KeyEvent e) {
		// TODO add your code here
	}

	private void btnSKeyTyped(KeyEvent e) {
		// TODO add your code here
	}

	private void btnAKeyPressed(KeyEvent e) {
		// TODO add your code here
	}

	private void btnAKeyReleased(KeyEvent e) {
		// TODO add your code here
	}

	private void btnAKeyTyped(KeyEvent e) {
		// TODO add your code here
	}

	private void btnDKeyPressed(KeyEvent e) {
		// TODO add your code here
	}

	private void btnDKeyReleased(KeyEvent e) {
		// TODO add your code here
	}

	private void btnDKeyTyped(KeyEvent e) {
		// TODO add your code here
	}

	private void btnWKeyPressed(KeyEvent e) {
		// TODO add your code here
	}

	private void btnWKeyReleased(KeyEvent e) {
		// TODO add your code here
	}

	private void btnWKeyTyped(KeyEvent e) {
		// TODO add your code here
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents  @formatter:off
		// Generated using JFormDesigner Educational license - Charlie Marzan (Charlie S Marzan)
		menuBar1 = new JMenuBar();
		menuHowtoplay = new JMenu();
		menuItem1 = new JMenuItem();
		menuItem2 = new JMenuItem();
		menuItem3 = new JMenuItem();
		btnStart = new JButton();
		btnExit = new JButton();
		btnS = new JButton();
		btnA = new JButton();
		btnD = new JButton();
		btnW = new JButton();
		lblObstacle14 = new JLabel();
		lblObstacle13 = new JLabel();
		lblObstacle12 = new JLabel();
		lblObstacle11 = new JLabel();
		lblObstacle10 = new JLabel();
		lblObstacle9 = new JLabel();
		lblObstacle8 = new JLabel();
		lblObstacle7 = new JLabel();
		lblObstacle6 = new JLabel();
		lblObstacle5 = new JLabel();
		lblObstacle = new JLabel();
		lblObstacle3 = new JLabel();
		lblObstacle2 = new JLabel();
		lblBackground = new JLabel();

		//======== this ========
		setTitle("Snake Game");
		Container contentPane = getContentPane();
		contentPane.setLayout(null);

		//======== menuBar1 ========
		{
			menuBar1.setOpaque(true);
			menuBar1.setBackground(new Color(0x006633));
			menuBar1.setForeground(Color.white);

			//======== menuHowtoplay ========
			{
				menuHowtoplay.setText("How to play?");
				menuHowtoplay.setBackground(new Color(0x006633));
				menuHowtoplay.setOpaque(true);
				menuHowtoplay.setForeground(Color.white);
				menuHowtoplay.setFont(new Font("Segoe UI Black", Font.BOLD, 14));

				//---- menuItem1 ----
				menuItem1.setText("Use W, A, S, D to control the snake.");
				menuItem1.setMargin(new Insets(3, 0, 3, 6));
				menuItem1.setIconTextGap(-10);
				menuItem1.setForeground(Color.white);
				menuItem1.setOpaque(true);
				menuItem1.setBackground(new Color(0x006633));
				menuHowtoplay.add(menuItem1);

				//---- menuItem2 ----
				menuItem2.setText("Avoid collisions with the snake's body and obstacles.");
				menuItem2.setMargin(new Insets(3, 0, 3, 6));
				menuItem2.setIconTextGap(-10);
				menuItem2.setForeground(Color.white);
				menuItem2.setOpaque(true);
				menuItem2.setBackground(new Color(0x006633));
				menuHowtoplay.add(menuItem2);

				//---- menuItem3 ----
				menuItem3.setText("Collect apples to grow longer.");
				menuItem3.setMargin(new Insets(3, 0, 3, 6));
				menuItem3.setIconTextGap(-10);
				menuItem3.setForeground(Color.white);
				menuItem3.setOpaque(true);
				menuItem3.setBackground(new Color(0x006633));
				menuHowtoplay.add(menuItem3);
			}
			menuBar1.add(menuHowtoplay);

			//---- btnStart ----
			btnStart.setText("START");
			btnStart.setOpaque(true);
			btnStart.setForeground(Color.white);
			btnStart.setBackground(new Color(0x006633));
			btnStart.setFont(new Font("Segoe UI", Font.BOLD, 14));
			menuBar1.add(btnStart);

			//---- btnExit ----
			btnExit.setText("EXIT");
			btnExit.setOpaque(true);
			btnExit.setForeground(Color.white);
			btnExit.setBackground(new Color(0x006633));
			btnExit.setFont(new Font("Segoe UI", Font.BOLD, 14));
			menuBar1.add(btnExit);
		}
		setJMenuBar(menuBar1);

		//---- btnS ----
		btnS.setIcon(new ImageIcon("pictures\\s.png"));
		btnS.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				btnSKeyPressed(e);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				btnSKeyReleased(e);
			}
			@Override
			public void keyTyped(KeyEvent e) {
				btnSKeyTyped(e);
			}
		});
		contentPane.add(btnS);
		btnS.setBounds(80, 505, 50, 40);

		//---- btnA ----
		btnA.setIcon(new ImageIcon("pictures\\a.png"));
		btnA.setFocusable(false);
		btnA.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				btnAKeyPressed(e);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				btnAKeyReleased(e);
			}
			@Override
			public void keyTyped(KeyEvent e) {
				btnAKeyTyped(e);
			}
		});
		contentPane.add(btnA);
		btnA.setBounds(30, 470, 50, 40);

		//---- btnD ----
		btnD.setIcon(new ImageIcon("pictures\\d.png"));
		btnD.setFocusable(false);
		btnD.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				btnDKeyPressed(e);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				btnDKeyReleased(e);
			}
			@Override
			public void keyTyped(KeyEvent e) {
				btnDKeyTyped(e);
			}
		});
		contentPane.add(btnD);
		btnD.setBounds(130, 470, 50, 40);

		//---- btnW ----
		btnW.setIcon(new ImageIcon("pictures\\w.png"));
		btnW.setFocusable(false);
		btnW.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				btnWKeyPressed(e);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				btnWKeyReleased(e);
			}
			@Override
			public void keyTyped(KeyEvent e) {
				btnWKeyTyped(e);
			}
		});
		contentPane.add(btnW);
		btnW.setBounds(80, 435, 50, 40);

		//---- lblObstacle14 ----
		lblObstacle14.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle14.setFocusable(false);
		contentPane.add(lblObstacle14);
		lblObstacle14.setBounds(860, 440, 60, 60);

		//---- lblObstacle13 ----
		lblObstacle13.setIcon(new ImageIcon("pictures\\2.png"));
		lblObstacle13.setFocusable(false);
		contentPane.add(lblObstacle13);
		lblObstacle13.setBounds(900, 65, 60, 60);

		//---- lblObstacle12 ----
		lblObstacle12.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle12.setFocusable(false);
		contentPane.add(lblObstacle12);
		lblObstacle12.setBounds(840, 185, 60, 60);

		//---- lblObstacle11 ----
		lblObstacle11.setIcon(new ImageIcon("pictures\\3.png"));
		lblObstacle11.setFocusable(false);
		contentPane.add(lblObstacle11);
		lblObstacle11.setBounds(760, 330, 60, 60);

		//---- lblObstacle10 ----
		lblObstacle10.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle10.setFocusable(false);
		contentPane.add(lblObstacle10);
		lblObstacle10.setBounds(605, 215, 60, 60);

		//---- lblObstacle9 ----
		lblObstacle9.setIcon(new ImageIcon("pictures\\2.png"));
		lblObstacle9.setFocusable(false);
		contentPane.add(lblObstacle9);
		lblObstacle9.setBounds(135, 330, 60, 60);

		//---- lblObstacle8 ----
		lblObstacle8.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle8.setFocusable(false);
		contentPane.add(lblObstacle8);
		lblObstacle8.setBounds(375, 260, 60, 60);

		//---- lblObstacle7 ----
		lblObstacle7.setIcon(new ImageIcon("pictures\\2.png"));
		lblObstacle7.setFocusable(false);
		contentPane.add(lblObstacle7);
		lblObstacle7.setBounds(210, 170, 60, 60);

		//---- lblObstacle6 ----
		lblObstacle6.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle6.setFocusable(false);
		contentPane.add(lblObstacle6);
		lblObstacle6.setBounds(555, 420, 60, 60);

		//---- lblObstacle5 ----
		lblObstacle5.setIcon(new ImageIcon("pictures\\3.png"));
		lblObstacle5.setFocusable(false);
		contentPane.add(lblObstacle5);
		lblObstacle5.setBounds(285, 430, 60, 60);

		//---- lblObstacle ----
		lblObstacle.setIcon(new ImageIcon("pictures\\3.png"));
		lblObstacle.setFocusable(false);
		contentPane.add(lblObstacle);
		lblObstacle.setBounds(365, 80, 60, 60);

		//---- lblObstacle3 ----
		lblObstacle3.setIcon(new ImageIcon("pictures\\2.png"));
		lblObstacle3.setFocusable(false);
		contentPane.add(lblObstacle3);
		lblObstacle3.setBounds(570, 85, 60, 60);

		//---- lblObstacle2 ----
		lblObstacle2.setIcon(new ImageIcon("pictures\\1.png"));
		lblObstacle2.setFocusable(false);
		contentPane.add(lblObstacle2);
		lblObstacle2.setBounds(100, 50, 60, 60);

		//---- lblBackground ----
		lblBackground.setIcon(new ImageIcon("pictures\\background.png"));
		lblBackground.setText("ST");
		contentPane.add(lblBackground);
		lblBackground.setBounds(0, 0, 1005, 570);

		{
			// compute preferred size
			Dimension preferredSize = new Dimension();
			for(int i = 0; i < contentPane.getComponentCount(); i++) {
				Rectangle bounds = contentPane.getComponent(i).getBounds();
				preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
				preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
			}
			Insets insets = contentPane.getInsets();
			preferredSize.width += insets.right;
			preferredSize.height += insets.bottom;
			contentPane.setMinimumSize(preferredSize);
			contentPane.setPreferredSize(preferredSize);
		}
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents  @formatter:on
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables  @formatter:off
	// Generated using JFormDesigner Educational license - Charlie Marzan (Charlie S Marzan)
	private JMenuBar menuBar1;
	private JMenu menuHowtoplay;
	private JMenuItem menuItem1;
	private JMenuItem menuItem2;
	private JMenuItem menuItem3;
	private JButton btnStart;
	private JButton btnExit;
	private JButton btnS;
	private JButton btnA;
	private JButton btnD;
	private JButton btnW;
	private JLabel lblObstacle14;
	private JLabel lblObstacle13;
	private JLabel lblObstacle12;
	private JLabel lblObstacle11;
	private JLabel lblObstacle10;
	private JLabel lblObstacle9;
	private JLabel lblObstacle8;
	private JLabel lblObstacle7;
	private JLabel lblObstacle6;
	private JLabel lblObstacle5;
	private JLabel lblObstacle;
	private JLabel lblObstacle3;
	private JLabel lblObstacle2;
	private JLabel lblBackground;
	// JFormDesigner - End of variables declaration  //GEN-END:variables  @formatter:on
}
